package sample;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;


public class Controller {
    @FXML
    private TextField textField1;

    @FXML
    private TextField textField2;


    @FXML
    private Text text1;
    @FXML
    private Text text2;
    @FXML
    private Text text3;

    @FXML
    private  ComboBox <String> comboBox1;
    @FXML
    private  ComboBox <String> comboBox2;

    public double tempConversion(String leftUnit, String rightUnit,String leftTemp) {
        double result = 0.0;
        String formula;
        String C;
        int K;
        int F = 0;


        if (leftUnit.equals("Cel")) {
            if (rightUnit.equals("Feh")) {
                result = Double.valueOf(leftTemp) * 9 / 5 + 32;
                text3.setText(String.valueOf(Double.valueOf(leftTemp)) +"°C * 9/5 + 32"+" = "+(result)+"F");
            } else if (rightUnit.equals("Kel")) {
                result = Double.valueOf(leftTemp) + 273.15;
                text3.setText(String.valueOf(Double.valueOf(leftTemp)) +"°C + 273.15"+" = "+(result)+"K");
            } else { result = Double.valueOf(leftTemp);
                text3.setText(String.valueOf(Double.valueOf(leftTemp)) +"°C"+" = "+(result)+"C");
            }


        }
        if (leftUnit.equals("Feh")  ){
            if (rightUnit.equals("Cel")) { result= (Double.valueOf(leftTemp)-32)* 5/9 ;
            text3.setText(String.valueOf(Double.valueOf(leftTemp)) +"F -32) * 5/9"+" = "+(result)+"°C");}
            else if (rightUnit.equals("Kel")){ result= (Double.valueOf(leftTemp)-32)* 5/9  + 273.15;
            text3.setText(String.valueOf(Double.valueOf(leftTemp)) +"F - 32) * 5/9"+" + 273.15 = "+(result)+"K");}
            else{result=Double.valueOf(leftTemp);
            text3.setText(String.valueOf(Double.valueOf(leftTemp)) +"F"+" = "+(result)+"F");}

        }
        if (leftUnit.equals("Kel")  ){
            if (rightUnit.equals("Cel")) { result= (Double.valueOf(leftTemp))-273.15;
            text3.setText(String.valueOf(Double.valueOf(leftTemp)) +"K - 273.15"+" = "+(result)+"°C");}

            else if (rightUnit.equals("Feh")){ result= (Double.valueOf(leftTemp)-273.15) * 9/5 +32;
            text3.setText(String.valueOf(Double.valueOf(leftTemp)) +"K - 273.15) * 9/5 + 32"+" = "+(result)+"F");}
            else{result=Double.valueOf(leftTemp);
            text3.setText(String.valueOf(Double.valueOf(leftTemp)) +"K"+" = "+(result)+"K");}




            }
        return result;
    }

        public double tempConversion_r(String leftUnit, String rightUnit,String rightTemp) {
            double result = 0.0;

            if (rightUnit.equals("Cel")) {
                if (leftUnit.equals("Feh")) {
                    result = Double.valueOf(rightTemp) * 9 / 5 + 32;
                    text3.setText(String.valueOf(Double.valueOf(rightTemp)) +"°C * 9/5 + 32"+" = "+(result)+"F");}
                else if (leftUnit.equals("Kel")) {
                    result = Double.valueOf(rightTemp) + 273.15;
                    text3.setText(String.valueOf(Double.valueOf(rightTemp)) +"°C + 273.15"+" = "+(result)+"K");}
                else { result = Double.valueOf(rightTemp);
                    text3.setText(String.valueOf(Double.valueOf(rightTemp)) +"°C"+" = "+(result)+"C");}
            }

                if (rightUnit.equals("Feh")  ) {
                    if (leftUnit.equals("Cel")) { result = (Double.valueOf(rightTemp) - 32) * 5 / 9;
                    text3.setText(String.valueOf(Double.valueOf(rightTemp)) +"F -32) * 5/9"+" = "+(result)+"°C");}
                    else if (leftUnit.equals("Kel")) { result = (Double.valueOf(rightTemp) - 32) * 5 / 9 + 273.15;
                    text3.setText(String.valueOf(Double.valueOf(rightTemp)) +"F - 32) * 5/9"+" + 273.15 = "+(result)+"K");}
                    else { result = Double.valueOf(rightTemp);
                    text3.setText(String.valueOf(Double.valueOf(rightTemp)) +"F"+" = "+(result)+"F");}

                }
                    if (rightUnit.equals("Kel")  ){
                        if (leftUnit.equals("Cel")) { result= (Double.valueOf(rightTemp))-273.15;
                        text3.setText(String.valueOf(Double.valueOf(rightTemp)) +"K - 273.15"+" = "+(result)+"°C");}

                        else if (leftUnit.equals("Feh")){ result= (Double.valueOf(rightTemp)-273.15 -32)* 5/9;
                        text3.setText("("+String.valueOf(Double.valueOf(rightTemp)) +"K - 273.15) * 9/5 + 32"+" = "+(result)+"F");}
                        else{result=Double.valueOf(rightTemp);
                        text3.setText( String.valueOf(Double.valueOf(rightTemp)) +"K"+" = "+(result)+"K");}
                }
                    return result;
    }
        @FXML
    public void ubdateTextField() {
            String leftUnit = comboBox1.getValue();
            String rightUnit = comboBox2.getValue();
            String leftTemp = textField1.getText();
            String rightTemp = textField2.getText();

//            System.out.println(leftUnit);
//            System.out.println(rightUnit);
//            System.out.println(leftTemp +  " 9 / 5 + 32");

//        String number2=textField2.getText();

//        text2.setText(leftTemp );
            textField2.setText(String.valueOf((tempConversion(leftUnit, rightUnit, leftTemp))));
//            text2.setText(String.valueOf(formula));
//            System.out.print(leftUnit+" " +rightUnit);
        }
            public void ubdateTextField_r(){
                String leftUnit=comboBox1.getValue();
                String rightUnit=comboBox2.getValue();
                String leftTemp=textField1.getText();
                String rightTemp=textField2.getText();
                textField1.setText(String.valueOf((tempConversion_r(leftUnit,rightUnit,rightTemp))));
//            System.out.print(leftUnit+" " +rightUnit);
}


//    @FXML
//        public void ubdateTextField2(){
//        text2.setText(comboBox1.getValue());
//
//
//    }
}
